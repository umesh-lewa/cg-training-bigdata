package com.dmac.javapc;

public class KafkaJavaCustomPartitioner {
}
