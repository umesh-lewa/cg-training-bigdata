package com.dmac.streams

object ScalaStreamProcessingMapTopic {

}
